<?php
require CLASS_PATH . 'terminology.inc.php';
$this->smarty->display($this->actionMode.".html");
?>
